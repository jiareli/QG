#include <REGX52.H>
#include <stdio.h>
#include "intrins.h"
#include "Delay.h"

#define uchar unsigned char
#define uint unsigned int
unsigned char NixieTable[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x7F,0x6F};
//unsigned int shu=0;
//unsigned char KeyNum=0;
uint shu=0;
uchar KeyNum=0;

void Delay1ms()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
}

//void Nixie(unsigned char Location,Number)
//{
//	switch(Location)
//	{
//	case 1:P2_4=1;P2_3=1;P2_2=1;break;
//	case 2:P2_4=1;P2_3=1;P2_2=0;break;
//	case 3:P2_4=1;P2_3=0;P2_2=1;break;
//	case 4:P2_4=1;P2_3=0;P2_2=0;break;
//	case 5:P2_4=0;P2_3=1;P2_2=1;break;
//	case 6:P2_4=0;P2_3=1;P2_2=0;break;
//	case 7:P2_4=0;P2_3=0;P2_2=1;break;
//	case 8:P2_4=0;P2_3=0;P2_2=0;break;
//	}
//	P0=NixieTable[Number];
//	Delay(1);
//	P0=0x00;
//}

void display()
{
	
	//P0=0x00;
	P2_4=1;P2_3=1;P2_2=1;
	//P2=0x01;//ǧλѡ
	P0=NixieTable[shu/1000];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=1;P2_2=0;
	//P2=0x02;//��λѡ
	P0=NixieTable[shu%1000/100];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=0;P2_2=1;
	//P2=0x04;//ʮλѡ
	P0=NixieTable[shu%100/10];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=0;P2_2=0;
	//P2=0x08;//��λѡ
	P0=NixieTable[shu%10];//��ѡ
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
}



//void keys()
//{
//	
//}

void main()
{
	while(1)
	{
		display();
		KeyNum=Key();
		if(KeyNum)			
		{
			if(KeyNum==1)	
			{
				shu++;
				if(shu==8888){shu=0;}
			 }
			if(KeyNum==2)	
			{
				shu--;
				if(shu==-1){shu=8888;}
			 }
			if(KeyNum==3)	
			{
				shu=0;
			 }
		 }

	}
}