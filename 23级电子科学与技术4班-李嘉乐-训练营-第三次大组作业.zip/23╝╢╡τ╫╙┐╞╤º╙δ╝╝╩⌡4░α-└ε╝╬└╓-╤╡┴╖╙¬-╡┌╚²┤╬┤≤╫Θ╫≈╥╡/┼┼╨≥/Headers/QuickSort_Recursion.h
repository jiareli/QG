#ifndef _QUICKSORT_RECURSION_H
#define _QUICKSORT_RECURSION_H

void quickSort(int a[], int left, int right);

#endif
#pragma once
