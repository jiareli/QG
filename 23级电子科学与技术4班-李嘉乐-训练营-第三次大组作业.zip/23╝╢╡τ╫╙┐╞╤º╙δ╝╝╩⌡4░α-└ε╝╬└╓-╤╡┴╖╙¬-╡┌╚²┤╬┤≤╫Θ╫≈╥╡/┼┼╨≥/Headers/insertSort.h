#ifndef _INSERT_SORT_H
#define _INSERT_SORT_H

void print_array(int arr[], int length);
void insert_sort(int arr[], int length);
void initArr(int arr[], int length);

#endif