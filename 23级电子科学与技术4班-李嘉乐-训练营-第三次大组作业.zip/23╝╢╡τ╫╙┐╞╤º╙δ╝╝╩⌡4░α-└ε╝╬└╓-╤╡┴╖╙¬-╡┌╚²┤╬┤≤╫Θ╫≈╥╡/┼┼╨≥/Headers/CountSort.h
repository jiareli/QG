#ifndef _COUNTSORT_H
#define _COUNTSORT_H

void countSort(int arr[], int length);

#endif#pragma once
