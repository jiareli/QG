#ifndef BST_H  
#define BST_H  

#include <stdio.h>  
#include <stdlib.h>  

#define true 1
#define false 0
#define succeed 1
#define failed 0
//#define Status int

typedef int ElemType;

//�����������ڵ�ṹ��
typedef struct treeNode
{
	char data;
	struct treeNode* LChild;
	struct treeNode* RChild;
}Tree, * LPTree;//LP����ָ��

//�����������Ľṹ��
typedef struct
{
	LPTree root;
}BSTree, * LPBSTree;

//�������ʽڵ�ĺ���ָ��
typedef void(*VisitFunc)(LPTree);

/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
int BST_init(LPBSTree);

LPTree BST_create(ElemType data);
void printTree(LPTree node);
int BST_preorderI_Helper(LPTree node, VisitFunc visit);
int BST_inorderI_Helper(LPTree node, VisitFunc visit);
int BST_postorderI_Helper(LPTree node, VisitFunc visit);
void PostorderTraversal(LPBSTree root, VisitFunc visit);

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
int BST_insert(LPBSTree tree, ElemType);

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
int BST_delete(LPTree* rootRef, ElemType data);
LPTree minValueNode(LPTree node);

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
int BST_search(LPBSTree tree, ElemType);

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_preorderI(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_preorderR(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_inorderI(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_inorderR(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_postorderI(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_postorderR(LPBSTree tree, void (*visit)(LPTree));

/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
int BST_levelOrder(LPBSTree tree, void (*visit)(LPTree));

void destroyTree(LPTree* root);

#endif // BST_H