#include <REGX52.H>
#include "Delay.h"
#include "UART.h"

void main()
{
	UART_Init();
	while(1)
	{
		Delay(1000);
		send_string("Hello World!\r\n");
	}
}
