#include <REGX52.H>
#include "Delay.h"
#include "UART.h"
#include "Intrins.h"

unsigned int shu=0;
unsigned char NixieTable[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x7F,0x6F};

void Delay1ms()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
}

void main()
{
	UART_Init();
	while(1)
	{
		
	}
}

void display()
{
	
	//P0=0x00;
	P2_4=1;P2_3=1;P2_2=1;
	//P2=0x01;//ǧλѡ
	P0=NixieTable[shu/1000];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=1;P2_2=0;
	//P2=0x02;//��λѡ
	P0=NixieTable[shu%1000/100];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=0;P2_2=1;
	//P2=0x04;//ʮλѡ
	P0=NixieTable[shu%100/10];//��ѡ3
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
	
	
	P2_4=1;P2_3=0;P2_2=0;
	//P2=0x08;//��λѡ
	P0=NixieTable[shu%10];//��ѡ
	//Delay(1);
	Delay1ms();//��ʱ
	P0=0x00;//��Ӱ
}


void UART_Rountine() interrupt 4
{
	if(RI==1)
	{
		shu=SBUF;
		RI=0;
		SBUF=shu;
		while(!TI);
		while(1)
		{
			display();
			if(RI==1)break;
		}
	}

}